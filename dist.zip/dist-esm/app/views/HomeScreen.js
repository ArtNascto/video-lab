// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { useState } from 'react';
import { Stack, PrimaryButton, Image, Text } from '@fluentui/react';
import heroSVG from '../../assets/hero.svg';
import { imgStyle, infoContainerStyle, configContainerStyle, configContainerStackTokens, containerStyle, containerTokens, headerStyle, buttonStyle } from '../styles/HomeScreen.styles';
import { ThemeSelector } from '../theming/ThemeSelector';
import { localStorageAvailable } from '../utils/localStorage';
import { getDisplayNameFromLocalStorage, saveDisplayNameToLocalStorage } from '../utils/localStorage';
import { DisplayNameField } from './DisplayNameField';
export const HomeScreen = (props) => {
    const imageProps = { src: heroSVG.toString() };
    const headerTitle = props.joiningExistingCall ? 'Join Call' : 'Start or join a call';
    // const callOptionsGroupLabel = 'Select a call option';
    const buttonText = 'Next';
    const callOptions = [
        // { key: 'ACSCall', text: 'Iniciar a chamada' },
        // { key: 'StartRooms', text: 'Iniciar a chamada' }
        { key: 'TeamsMeeting', text: 'Iniciar a chamada' },
        // { key: 'Rooms', text: 'Join a Rooms Call' }
    ];
    // const roomIdLabel = 'Room ID';
    // const roomsRoleGroupLabel = 'Rooms Role';
    /* @conditional-compile-remove(rooms) */
    const roomRoleOptions = [
        { key: 'Consumer', text: 'Consumer' },
        { key: 'Presenter', text: 'Presenter' },
        { key: 'Attendee', text: 'Attendee' }
    ];
    // Get display name from local storage if available
    const defaultDisplayName = localStorageAvailable ? getDisplayNameFromLocalStorage() : null;
    const [displayName, setDisplayName] = useState(defaultDisplayName !== null && defaultDisplayName !== void 0 ? defaultDisplayName : undefined);
    const [chosenCallOption] = useState(callOptions[0]);
    const [callLocator] = useState();
    const [chosenRoomsRoleOption] = useState(roomRoleOptions[1]);
    const startGroupCall = chosenCallOption.key === 'ACSCall';
    const teamsCallChosen = chosenCallOption.key === 'TeamsMeeting';
    const buttonEnabled = displayName && (startGroupCall || (teamsCallChosen && callLocator) || chosenRoomsRoleOption);
    const showDisplayNameField = true;
    return (React.createElement(Stack, { horizontal: true, wrap: true, horizontalAlign: "center", verticalAlign: "center", tokens: containerTokens, className: containerStyle },
        React.createElement(Image, Object.assign({ alt: "Welcome to the ACS Calling sample app", className: imgStyle }, imageProps)),
        React.createElement(Stack, { className: infoContainerStyle },
            React.createElement(Text, { role: 'heading', "aria-level": 1, className: headerStyle }, headerTitle),
            React.createElement(Stack, { className: configContainerStyle, tokens: configContainerStackTokens },
                showDisplayNameField && React.createElement(DisplayNameField, { defaultName: displayName, setName: setDisplayName }),
                React.createElement(PrimaryButton, { disabled: !buttonEnabled, className: buttonStyle, text: buttonText, onClick: () => {
                        if (displayName) {
                            displayName && saveDisplayNameToLocalStorage(displayName);
                            props.startCallHandler({
                                //TODO: This needs to be updated after we change arg types of TeamsCall
                                displayName: !displayName ? 'Teams UserName PlaceHolder' : displayName,
                                callLocator: callLocator,
                                option: chosenCallOption.key,
                                role: chosenRoomsRoleOption.key
                            });
                        }
                    } }),
                React.createElement("div", null,
                    React.createElement(ThemeSelector, { label: "Theme", horizontal: true }))))));
};
// componentDidMount: function() {
//   var $this = $(ReactDOM.findDOMNode(this));
//   setChosenCallOption({ key: 'StartRooms', text: 'Start a Rooms call' });
//   setRoomsRoleOption({ key: 'Consumer', text: 'Consumer' });
// }
//# sourceMappingURL=HomeScreen.js.map