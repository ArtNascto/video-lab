export declare const videoCameraIconStyle: any;
export declare const buttonStyle: any;
//# sourceMappingURL=StartCallButton.styles.d.ts.map