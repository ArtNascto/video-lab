export declare const TextFieldStyleProps: {
    fieldGroup: {
        height: string;
    };
};
export declare const inputBoxStyle: any;
export declare const inputBoxTextStyle: any;
//# sourceMappingURL=DisplayNameField.styles.d.ts.map