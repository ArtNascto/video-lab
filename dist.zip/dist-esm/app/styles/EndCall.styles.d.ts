import { IButtonStyles, IStackTokens } from '@fluentui/react';
export declare const mainStackTokens: IStackTokens;
export declare const buttonsStackTokens: IStackTokens;
export declare const upperStackTokens: IStackTokens;
export declare const bottomStackTokens: IStackTokens;
export declare const endCallContainerStyle: any;
export declare const endCallTitleStyle: any;
export declare const buttonStyle: any;
export declare const buttonWithIconStyles: IButtonStyles;
export declare const videoCameraIconStyle: any;
export declare const bottomStackFooterStyle: any;
//# sourceMappingURL=EndCall.styles.d.ts.map