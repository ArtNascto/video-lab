import { IButtonStyles, IStackStyles, IStackTokens, ITextFieldStyles } from '@fluentui/react';
export declare const paneFooterStyles: IStackStyles;
export declare const paneFooterTokens: IStackTokens;
export declare const textFieldStyles: Partial<ITextFieldStyles>;
export declare const footerMainTextStyle: any;
export declare const copyLinkButtonStyle: any;
export declare const buttonWithIconStyles: IButtonStyles;
export declare const copyIconStyle: any;
//# sourceMappingURL=Footer.styles.d.ts.map