import { IStackTokens } from '@fluentui/react';
export declare const imgStyle: any;
export declare const containerTokens: IStackTokens;
export declare const infoContainerStyle: any;
export declare const containerStyle: any;
export declare const configContainerStyle: any;
export declare const configContainerStackTokens: IStackTokens;
export declare const callContainerStackTokens: IStackTokens;
export declare const callOptionsGroupStyles: {
    label: {
        padding: number;
    };
};
export declare const headerStyle: any;
export declare const bodyItemStyle: any;
export declare const teamsItemStyle: any;
export declare const buttonStyle: any;
//# sourceMappingURL=HomeScreen.styles.d.ts.map